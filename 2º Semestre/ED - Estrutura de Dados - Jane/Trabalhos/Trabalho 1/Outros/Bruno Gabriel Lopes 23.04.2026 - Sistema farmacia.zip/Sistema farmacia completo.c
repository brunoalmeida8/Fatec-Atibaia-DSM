#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

typedef struct tipo_registro Registro;

struct tipo_registro
{
    int codigoMedicamento;
    char nome[30];
    int QtdEstoque;
    double precoUnitario;
};

void cadastrar(Registro *estoque, int *qtd)
{
    printf("Quantos medicamentos ir� cadastrar: ");
    scanf("%d", qtd);

    for(int i = 0; i < *qtd; i++){
        printf("\n========= Cadastrar Medicamento %d ==========\n", i + 1);

        printf("CODIGO: ");
        scanf("%d", &estoque[i].codigoMedicamento);

        printf("NOME: ");
        scanf("%s", estoque[i].nome);

        printf("QUANTIDADE EM ESTOQUE: ");
        scanf("%d", &estoque[i].QtdEstoque);

        printf("PRE�O UNIT�RIO: ");
        scanf("%lf", &estoque[i].precoUnitario);
    }
}


void buscar(Registro *estoque, int qtd) {
    int codigo;
    printf("\nDigite o c�digo do medicamento: ");
    scanf("%d", &codigo);

    for (int i = 0; i < qtd; i++) {
        if (estoque[i].codigoMedicamento == codigo) {
            printf("\n\n=== Medicamento encontrado ===\n");
            printf("C�digo: %d\n", estoque[i].codigoMedicamento);
            printf("Nome: %s\n", estoque[i].nome);
            printf("Quantidade: %d\n", estoque[i].QtdEstoque);
            printf("Pre�o: R$ %.2f\n", estoque[i].precoUnitario);
            return;
        }
    }
}

int main()
{
    setlocale(LC_ALL,"PORTUGUESE");

    int qtd = 0;
    int opcao;
    Registro *estoque = NULL;

    do {
        printf("\n===== MENU =====\n");
        printf("1 - Cadastrar medicamentos\n");
        printf("2 - Listar medicamentos\n");
        printf("3 - Buscar medicamento por c�digo\n");
        printf("4 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        switch (opcao) {

        case 1:

            estoque = malloc(qtd * sizeof(Registro));

            cadastrar(estoque, &qtd);
            break;

        case 2:
            if (estoque == NULL) {
                printf("<<<<<<<<<<<<<  Nenhum medicamento cadastrdo!  >>>>>>>>>>>>>\n");
                break;
            }

            printf("\n=== DADOS CADASTRADOS ===\n");
            for(int i = 0; i < qtd; i++){
                printf("\nMedicamento %d:\n", i + 1);
                printf("C�digo: %d\n", estoque[i].codigoMedicamento);
                printf("Nome: %s\n", estoque[i].nome);
                printf("Quantidade: %d\n", estoque[i].QtdEstoque);
                printf("Pre�o: %.2lf\n", estoque[i].precoUnitario);
            }
            break;

        case 3:
            if (estoque == NULL){
                printf("\n<<<<<<<<<  Nada cadastrado  >>>>>>>>>>>\n");
            }
            else
            buscar(estoque, qtd);
            break;

        case 4:
            printf("\n<<<<<<<<<<<<  Programa encerrado... >>>>>>>>>>>>\n");
            break;

        default:
            printf("<<<<<<<<<<<<  Op��o inv�lida!  >>>>>>>>>>>>\n");
            break;
        }

    } while (opcao != 4);

    free(estoque);
    return 0;
}

