#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

typedef struct
{
    int codigo;
    char nome[100];
    int quantidade;
    double preco;
} Medicamento;

void remover_quebra_linha(char texto[])
{
    texto[strcspn(texto, "\n")] = '\0';
}

void mostrar_menu(void)
{
    printf("\n-------------------------------");
    printf("\n1 - Cadastrar medicamento");
    printf("\n2 - Listar medicamentos");
    printf("\n3 - Buscar por código");
    printf("\n4 - Sair");
    printf("\n-------------------------------");
    printf("\nEscolha uma opção: ");
}

void ler_medicamento(Medicamento *med)
{
    printf("Código: ");
    scanf("%d", &med->codigo);
    getchar();

    printf("Nome: ");
    fgets(med->nome, sizeof(med->nome), stdin);
    remover_quebra_linha(med->nome);

    printf("Quantidade em estoque: ");
    scanf("%d", &med->quantidade);

    printf("Preço unitário: ");
    scanf("%lf", &med->preco);
    getchar();
}

void exibir_medicamento(const Medicamento *med)
{
    printf("\nCódigo: %d", med->codigo);
    printf("\nNome: %s", med->nome);
    printf("\nQuantidade: %d", med->quantidade);
    printf("\nPreço: %.2lf\n", med->preco);
}

int buscar_indice_por_codigo(const Medicamento *lista, int total, int codigo)
{
    for (int i = 0; i < total; i++)
    {
        if (lista[i].codigo == codigo)
        {
            return i;
        }
    }

    return -1;
}

int garantir_capacidade(Medicamento **lista, int capacidade_atual, int total, int novos)
{
    if (total + novos <= capacidade_atual)
    {
        return capacidade_atual;
    }

    int nova_capacidade = capacidade_atual == 0 ? 2 : capacidade_atual;

    while (total + novos > nova_capacidade)
    {
        nova_capacidade *= 2;
    }

    Medicamento *temp = realloc(*lista, nova_capacidade * sizeof(Medicamento));
    if (temp == NULL)
    {
        printf("\nErro ao alocar memória.\n");
        return capacidade_atual;
    }

    *lista = temp;
    return nova_capacidade;
}

void cadastrar_medicamentos(Medicamento **lista, int *total, int *capacidade)
{
    int quantidade;

    printf("\nQuantos medicamentos deseja cadastrar? ");
    scanf("%d", &quantidade);
    getchar();

    if (quantidade <= 0)
    {
        printf("\nQuantidade inválida.\n");
        return;
    }

    int capacidade_anterior = *capacidade;
    *capacidade = garantir_capacidade(lista, *capacidade, *total, quantidade);

    if (*capacidade == capacidade_anterior && *total + quantidade > *capacidade)
    {
        return;
    }

    for (int i = 0; i < quantidade; i++)
    {
        printf("\nMedicamento %d\n", *total + 1);
        ler_medicamento(&(*lista)[*total]);
        (*total)++;
    }

    printf("\nCadastro concluído com sucesso.\n");
}

void listar_medicamentos(const Medicamento *lista, int total)
{
    if (total == 0)
    {
        printf("\nNenhum medicamento cadastrado.\n");
        return;
    }

    for (int i = 0; i < total; i++)
    {
        printf("\n------------------------------");
        printf("\nMedicamento %d", i + 1);
        printf("\n------------------------------");
        exibir_medicamento(&lista[i]);
    }
}

void buscar_medicamento(const Medicamento *lista, int total)
{
    int codigo;
    int indice;

    if (total == 0)
    {
        printf("\nNenhum medicamento cadastrado.\n");
        return;
    }

    printf("\nInforme o código do medicamento: ");
    scanf("%d", &codigo);

    indice = buscar_indice_por_codigo(lista, total, codigo);

    if (indice == -1)
    {
        printf("\nMedicamento não encontrado.\n");
        return;
    }

    printf("\nMedicamento encontrado:");
    exibir_medicamento(&lista[indice]);
}

int main(void)
{
    setlocale(LC_ALL, "Portuguese");

    Medicamento *medicamentos = NULL;
    int total = 0;
    int capacidade = 0;
    int opcao;

    do
    {
        mostrar_menu();
        scanf("%d", &opcao);
        getchar();

        switch (opcao)
        {
            case 1:
                cadastrar_medicamentos(&medicamentos, &total, &capacidade);
                break;
            case 2:
                listar_medicamentos(medicamentos, total);
                break;
            case 3:
                buscar_medicamento(medicamentos, total);
                break;
            case 4:
                printf("\nPrograma encerrado.\n");
                break;
            default:
                printf("\nOpção inválida.\n");
        }

    } while (opcao != 4);

    free(medicamentos);
    return 0;
}