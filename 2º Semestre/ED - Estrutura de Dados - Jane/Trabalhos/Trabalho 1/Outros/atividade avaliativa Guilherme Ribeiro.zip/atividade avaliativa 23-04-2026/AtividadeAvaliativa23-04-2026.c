#include <stdio.h>
#include <stdlib.h>

struct Medicamento {
    int codigo;
    char nome[50];
    int quantidade;
    float preco;
};

void cadastrar(struct Medicamento *v, int tamanho) {
    int i;
    for (i = 0; i < tamanho; i++) {
        printf("Cadastro %d\n", i + 1);
        printf("Codigo: ");
        scanf("%d", &v[i].codigo);
        printf("Nome: ");
        scanf("%s", v[i].nome);
        printf("Quantidade: ");
        scanf("%d", &v[i].quantidade);
        printf("Preco: ");
        scanf("%f", &v[i].preco);
    }
}

void listar(struct Medicamento *v, int tamanho) {
    int i;
    for (i = 0; i < tamanho; i++) {
        printf("Codigo: %d | Nome: %s | Quantidade: %d | R$: %.2f\n",
               v[i].codigo, v[i].nome, v[i].quantidade, v[i].preco);
    }
}

void buscar(struct Medicamento *v, int tamanho) {
    int i;
    int codProcurado;
    printf("Digite o codigo: ");
    scanf("%d", &codProcurado);

    for (i = 0; i < tamanho; i++) {
        if (v[i].codigo == codProcurado) {
            printf("Encontrado: %s\n", v[i].nome);
            printf("Codigo: %d\n", v[i].codigo);
            printf("Nome: %s\n", v[i].nome);
            printf("Quantidade: %d\n", v[i].quantidade);
            printf("Preco: R$ %.2f\n", v[i].preco);
            return;
        }
    }
}

int main() {
    int opcao = 0;
    int total = 0;
    struct Medicamento *estoque = NULL;

    while (opcao != 4) {
        printf("\n1) Cadastrar medicamentos\n2) Listar medicamentos\n3) Buscar medicamento por codigo\n4) Sair\n");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("Quantos medicamentos quer cadastrar? ");
            scanf("%d", &total);
            estoque = malloc(total * sizeof(struct Medicamento));
            cadastrar(estoque, total);
        }
        if (opcao == 2) {
            if (total > 0) {
                listar(estoque, total);
            } else {
                printf("Nada cadastrado.\n");
            }
        }
        if (opcao == 3) {
            if (total > 0) {
                buscar(estoque, total);
            } else {
                printf("Estoque vazio.\n");
            }
        }
    }
    free(estoque);
    return 0;
}
