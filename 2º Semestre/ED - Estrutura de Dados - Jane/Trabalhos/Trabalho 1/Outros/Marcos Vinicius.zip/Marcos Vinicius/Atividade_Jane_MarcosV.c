#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int codigo;
    char nome[50];
    int quantidade;
    float preco;
} Medicamento;

void cadastrar(Medicamento *m, int n) {
    int i;
    for(i = 0; i < n; i++) {
        printf("Codigo: ");
        scanf("%d", &m[i].codigo);
        printf("Nome: ");
        scanf(" %[^\n]", m[i].nome);
        printf("Quantidade: ");
        scanf("%d", &m[i].quantidade);
        printf("Preco: ");
        scanf("%f", &m[i].preco);
    }
}

void listar(Medicamento *m, int n) {
    int i;
    for(i = 0; i < n; i++) {
        printf("\nCodigo: %d\n", m[i].codigo);
        printf("Nome: %s\n", m[i].nome);
        printf("Quantidade: %d\n", m[i].quantidade);
        printf("Preco: %.2f\n", m[i].preco);
    }
}

void buscar(Medicamento *m, int n) {
    int cod, i, achou = 0;
    printf("Digite o codigo: ");
    scanf("%d", &cod);

    for(i = 0; i < n; i++) {
        if(m[i].codigo == cod) {
            printf("\nCodigo: %d\n", m[i].codigo);
            printf("Nome: %s\n", m[i].nome);
            printf("Quantidade: %d\n", m[i].quantidade);
            printf("Preco: %.2f\n", m[i].preco);
            achou = 1;
        }
    }

    if(achou == 0) {
        printf("Nao encontrado\n");
    }
}

int main() {
    Medicamento *m;
    int n, op = 0;

    printf("Quantidade de medicamentos: ");
    scanf("%d", &n);

    m = (Medicamento*) malloc(n * sizeof(Medicamento));

    while(op != 4) {
        printf("\n1 Cadastrar\n2 Listar\n3 Buscar\n4 Sair\n");
        scanf("%d", &op);

        if(op == 1) {
            cadastrar(m, n);
        } else if(op == 2) {
            listar(m, n);
        } else if(op == 3) {
            buscar(m, n);
        }
    }

    free(m);

    return 0;
}
