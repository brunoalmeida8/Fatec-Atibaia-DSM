#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

typedef struct {
    int codigo;
    char nome[50];
    int qtde;
    float preco;
} Medicamento;

void cadastrarMedicamentos(Medicamento *vetor, int tamanhoVetor) {
    for(int i = 0; i < tamanhoVetor; i++) {
        printf("\n--- Cadastro de Medicamentos %d ---\n", i + 1);

        printf("C�digo: ");
        scanf("%d", &vetor[i].codigo);
        getchar();

        printf("Nome do medicamento: ");
        fgets(vetor[i].nome, 50, stdin);
        vetor[i].nome[strcspn(vetor[i].nome, "\n")] = '\0';

        printf("Quantidade em estoque: ");
        scanf("%d", &vetor[i].qtde);

        printf("Pre�o unit�rio: ");
        scanf("%f", &vetor[i].preco);
    }
    printf("\nCadastro conclu�do com sucesso!\n");
}

void listarMedicamentos(Medicamento *vetor, int tamanhoVetor) {
    printf("\n=== MEDICAMENTOS EM ESTOQUE ===\n");
    for(int i = 0; i < tamanhoVetor; i++) {
        printf("\nC�digo: %d | Nome: %s | Quantidade: %d | Pre�o: R$ %.2f\n",
               vetor[i].codigo, vetor[i].nome, vetor[i].qtde, vetor[i].preco);
    }
    printf("\n==============================================================\n");
}

void buscarMedicamento(Medicamento *vetor, int tamanhoVetor, int *codigoBusca) {
    int encontrou = 0;
    for(int i = 0; i < tamanhoVetor; i++) {
        if(vetor[i].codigo == *codigoBusca) {
            printf("\nMedicamento Em Estoque!\n");
            printf("\nC�digo: %d | Nome: %s | Qtd: %d | Pre�o: R$ %.2f\n",
                   vetor[i].codigo, vetor[i].nome, vetor[i].qtde, vetor[i].preco);
            encontrou = 1;
            break;
        }
    }

    if(encontrou == 0) {
        printf("\nErro: Medicamento com c�digo %d n�o encontrado no sistema!\a\n", *codigoBusca);
    }
}

int main() {

    setlocale(LC_ALL, "Portuguese");

    int opcao;
    int qtde = 0;
    int foiCadastrado = 0;
    Medicamento *estoque = NULL;
    int codBusca;

    printf("============ Bem-vindo ao Sistema da Farm�cia! ============\n");

    printf("\nInforme a quantidade de medicamentos que deseja cadastrar: ");
    scanf("%d", &qtde);

    if (qtde > 0) {
        estoque = (Medicamento*) malloc(qtde * sizeof(Medicamento));

        if (estoque == NULL) {
            printf("Erro ao alocar mem�ria!\a\n");
            return 1;
        }
    }

    do {
        printf("\n=== MENU FARM�CIA ===\n");
        printf("1 - Cadastrar medicamentos\n");
        printf("2 - Listar medicamentos\n");
        printf("3 - Buscar medicamento por c�digo\n");
        printf("4 - Sair\n");
        printf("Escolha uma op��o: ");
        scanf("%d", &opcao);

        switch(opcao) {
            case 1:
                if (qtde > 0) {
                    cadastrarMedicamentos(estoque, qtde);
                    foiCadastrado = 1;
                } else {
                    printf("\nO sistema est� dispon�vel somente para consulta, j� zero medicamentos seriam cadastrados!\a\n");
                }
                break;
            case 2:
                if (qtde == 0 || foiCadastrado == 0) {
                    printf("\nO estoque atualmente n�o possui nenhum medicamento!\a\n");
                } else {
                    listarMedicamentos(estoque, qtde);
                }
                break;
            case 3:
                if (qtde == 0 || foiCadastrado == 0) {
                    printf("\nO estoque atualmente n�o possui nenhum medicamento!\n");
                } else {
                    printf("\nInforme o c�digo do medicamento que deseja buscar: ");
                    scanf("%d", &codBusca);
                    buscarMedicamento(estoque, qtde, &codBusca);
                }
                break;
            case 4:
                printf("\nSaindo do sistema...\nAt� logo!\n");
                break;
            default:
                printf("\nOp��o inv�lida!\n");
        }
    } while(opcao != 4);

    if (estoque != NULL) {
        free(estoque);
    }

    return 0;
}
