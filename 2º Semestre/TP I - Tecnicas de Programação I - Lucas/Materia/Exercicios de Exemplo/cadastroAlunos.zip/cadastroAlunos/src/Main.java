//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        Aluno a1 = new Aluno("Marina Costa", 16, "3ºA");
        Aluno a2 = new Aluno("Pedro Lima", "2ºB");
        Aluno a3 = new Aluno("Júlia Alves");

        a1.exibirDados();
        a2.exibirDados();
        a3.exibirDados();

        System.out.println("Total de alunos: " + Aluno.getTotalAlunos());
    }
}