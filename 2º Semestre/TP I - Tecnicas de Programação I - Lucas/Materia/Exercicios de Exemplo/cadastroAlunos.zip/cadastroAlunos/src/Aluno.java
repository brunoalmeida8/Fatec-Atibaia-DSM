public class Aluno {

    private String nome;
    private int idade;
    private String turma;
    static int totalAlunos = 0;

    public Aluno(String nome, int idade, String turma) {
        this.nome = nome;
        this.idade = idade;
        this.turma = turma;
        totalAlunos++;
    }

    public Aluno(String nome, String turma) {
        this.nome = nome;
        this.turma = turma;
        this.idade = 0;
        totalAlunos++;
    }

    public Aluno(String nome) {
        this.nome = nome;
        this.idade = 0;
        this.turma = "Não definida";
        totalAlunos++;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getTurma() {
        return turma;
    }

    public static int getTotalAlunos() {
        return totalAlunos;
    }

    public void exibirDados(){

        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Turma: " + turma);
        System.out.println("Quantidade de Alunos: " + turma);

    }
}
