import java.util.PrimitiveIterator;

public class Livro {
    //ATRIBUTOS
    private String nome;
    private int ano;
    private Double valor;
    private int quantidade;

    //CONSTRUTOR
    public Livro(String nome, int ano, Double valor, int quantidade) {
        this.nome = nome;
        this.ano = ano;
        this.valor = valor;
        this.quantidade = quantidade;
    }

    //METODOS DE ACESSO PUBLICO GET E SET

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    //METODOS DE AÇÃO
    public void apresentarLivro(){
        System.out.println("Nome: " + nome);
        System.out.println("Ano de publicação: " + ano);
        System.out.println("Valor: " + valor);
    }

    //neste metodo calculamos o valor * quantidade em uma variavel do metodo.
    public void calcularValorEstoque(){
        double valorEstoque = valor * quantidade;
        System.out.println("O valor em estoque é de: " + valorEstoque);

        //neste exemplo estamos usando um if caso a quantidade seja menor que 3 livros.
        //se for menor, a mensagem será apresentada.
        if (quantidade < 3){
            System.out.println("Quantidade de livros baixa, apenas " + quantidade + " disponiveis.");
        }
    }
}
