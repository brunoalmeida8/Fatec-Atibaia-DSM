//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

            //INSTANCIAÇÃO DO OBJETO
        Livro l1 = new Livro("Aprendendo Java", 2020, 150.00);

        //CHAMADA DO METODO APRESENTAR LIVRO DO OBJETO l1
        l1.apresentarLivro();
    }
}