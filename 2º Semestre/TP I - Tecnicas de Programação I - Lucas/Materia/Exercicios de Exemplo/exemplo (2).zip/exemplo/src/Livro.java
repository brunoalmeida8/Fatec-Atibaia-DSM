public class Livro {
    //ATRIBUTOS
    private String nome;
    private int ano;
    private Double valor;

    //CONSTRUTOR
    public Livro(String nome, int ano, Double valor) {
        this.nome = nome;
        this.ano = ano;
        this.valor = valor;
    }
    //METODOS DE ACESSO PUBLICO GET E SET

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    //METODOS DE AÇÃO
    public void apresentarLivro(){
        System.out.println("Nome: " + nome);
        System.out.println("Ano de publicação: " + ano);
        System.out.println("Valor: " + valor);
    }
}
