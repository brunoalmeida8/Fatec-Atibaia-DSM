public class Livro {
    //ATRIBUTOS
    public String nome;
    public int ano;
    public Double valor;

    //CONSTRUTOR
    public Livro(String nome, int ano, Double valor) {
        this.nome = nome;
        this.ano = ano;
        this.valor = valor;
    }
    //METODOS
    public void apresentarLivro(){
        System.out.println("Nome: " + nome);
        System.out.println("Ano de publicação: " + ano);
        System.out.println("Valor: " + valor);
    }
}
