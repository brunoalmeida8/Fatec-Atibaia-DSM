public class Funcionario {
    //ATRIBUTOS
    private String nome;
    private String cargo;
    private double salario;

    //CONSTRUTORES
    public Funcionario(){
        this.nome = "Sem informação";
        this.cargo = "Sem informação";
        this.salario = 0;
    }
    public Funcionario(String nome, double salario){
        this.nome = nome;
        this.salario = salario;
    }
    public Funcionario(String nome, String cargo){
        this.nome = nome;
        this.cargo = cargo;
    }

    public Funcionario(String nome, String cargo, double salario){
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }
    public void exibirDados(){
        System.out.println("Nome: " + nome);
        System.out.println("Cargo: " + this.cargo);
        System.out.println("Salario: " + this.salario);
    }
    public double aumentarSalario(double percentual){
        this.salario = (this.salario / 100) * percentual + this.salario;
        return this.salario;
    }
}












