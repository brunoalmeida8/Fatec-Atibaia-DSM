﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PetshopMVC.Models;

namespace PetshopMVC.Repositories
{
    public interface IPetRepository
    {
        Task<IEnumerable<Pet>> GetAllAsync();
        Task<Pet?> GetByIdAsync(int id);
        Task AddAsync(Pet pet);
        Task UpdateAsync(Pet pet);
        Task DeleteAsync(int id);
    }
}
