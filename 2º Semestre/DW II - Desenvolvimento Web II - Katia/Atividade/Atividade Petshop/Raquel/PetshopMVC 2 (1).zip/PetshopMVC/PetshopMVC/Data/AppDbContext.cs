﻿using Microsoft.EntityFrameworkCore;
using PetshopMVC.Models;

namespace PetshopMVC.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Pet> Pets { get; set; }
    }
}