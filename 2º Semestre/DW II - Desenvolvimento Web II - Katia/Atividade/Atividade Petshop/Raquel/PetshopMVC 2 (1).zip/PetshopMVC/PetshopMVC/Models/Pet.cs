﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PetshopMVC.Models
{
    [Table("pets")]
    public class Pet
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Informe o nome do tutor")]
        [StringLength(100)]
        public string Tutor { get; set; } = "";

        [Required(ErrorMessage = "Informe o nome do pet")]
        [StringLength(100)]
        public string Nome { get; set; } = "";

        [Required(ErrorMessage = "Informe a espécie")]
        [StringLength(50)]
        public string Especie { get; set; } = "";

        [StringLength(50)]
        public string? Raca { get; set; }

        [Column("dataNascimento")]
        [Display(Name = "Data de Nascimento")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? DataNascimento { get; set; }
    }
}