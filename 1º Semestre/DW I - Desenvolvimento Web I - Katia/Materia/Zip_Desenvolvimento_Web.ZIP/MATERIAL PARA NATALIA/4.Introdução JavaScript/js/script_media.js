// seleciona o botão Calcular média pelo id
const btncalcular = document.getElementById("btnCalcular");
// adicionar um evento de cique ao botão calcular
btncalcular.addEventListener("click", calcularMedia);
// função responsável por calcular a média
function calcularMedia(){
    // selecionar os campos de entrada e converte os valores para número
    const n1 = Number(document.getElementById("nota1").value);
    const n2 = Number(document.getElementById("nota2").value);
    const n3 = Number(document.getElementById("nota3").value);
    const media = (n1 + n2 + n3) / 3;
    // seleciona a div resultado
    const divResultado = document.getElementById("resultado");
    // remove o conteúdo antigo antes de inserir um novo
    divResultado.innerHTML="";
    //cria um novo elemento <p> para exibir a média
    const paragrafo = document.createElement("p");
    // define o texto do parágrafo com a média formatada
    paragrafo.innerText = `Média = ${media.toFixed(2)}`;
    const situacao = document.createElement("p");
    if(media >= 5) {
        situacao.innerText = "Aprovado!";
    } else {
        situacao.innerText = "Reprovado!";
    }    
    // adiciona o parágrafo como filho da div resultado
    divResultado.appendChild(paragrafo);
    divResultado.appendChild(situacao);    
}